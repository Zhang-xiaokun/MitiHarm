import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence



class healthRec(nn.Module):

    def __init__(self, n_items, hidden_size, embedding_dim, batch_size, datasets, ui_lambda, item_lambda, user_lambda, n_layers=1):
        super(healthRec, self).__init__()
        self.n_items = n_items
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.n_layers = n_layers
        self.embedding_dim = embedding_dim
        self.emb = nn.Embedding(self.n_items, self.embedding_dim, padding_idx=0)

        self.emb_healthy = nn.Embedding(2, 768, padding_idx=0)
        self.emb_harmful = nn.Embedding(2, 768, padding_idx=0)
        self.emb_reason = nn.Embedding(self.n_items, self.embedding_dim, padding_idx=0)

        self.ui_lambda = ui_lambda
        self.item_lambda = item_lambda
        self.user_lambda = user_lambda

        text_emb_path = './datasetsHealth/' + datasets + '/H_title_emb100.npy'
        textWeights = np.load(text_emb_path)
        self.emb.weight.data.copy_(torch.from_numpy(textWeights))

        reason_emb_path = './datasetsHealth/' + datasets + '/H_reason_emb100.npy'
        reasonWeights = np.load(reason_emb_path)
        self.emb_reason.weight.data.copy_(torch.from_numpy(reasonWeights))

        self.emb_reason.weight.requires_grad = False

        health_emb_path = './datasetsHealth/' + datasets + '/H_pos_emb100.npy'
        healWeights = np.load(health_emb_path)
        self.emb_healthy.weight.data.copy_(torch.from_numpy(healWeights))

        self.emb_healthy.weight.requires_grad = False

        harm_emb_path = './datasetsHealth/' + datasets + '/H_neg_emb100.npy'
        harmWeights = np.load(harm_emb_path)
        self.emb_harmful.weight.data.copy_(torch.from_numpy(harmWeights))

        self.emb_harmful.weight.requires_grad = False

        self.dense_text_health = nn.Linear(768, self.embedding_dim)
        self.dense_text_harm = nn.Linear(768, self.embedding_dim)

        self.cos_sim = nn.CosineSimilarity(dim=-1)
        self.ul_W1 = nn.Linear(self.embedding_dim, self.embedding_dim)
        self.ul_W2 = nn.Linear(self.embedding_dim, self.embedding_dim)
        self.ul_W3 = nn.Linear(self.embedding_dim, self.embedding_dim)

        self.merge_item = nn.Linear(self.embedding_dim, self.embedding_dim)

        # self_attention
        num_heads = 4
        if self.embedding_dim % num_heads != 0:  # 整除
            raise ValueError(
                "The hidden size (%d) is not a multiple of the number of attention "
                "heads (%d)" % (self.embedding_dim, num_heads))
            # 参数定义
        self.num_heads = num_heads  # 4
        self.attention_head_size = int(self.embedding_dim / self.num_heads)  # 16  每个注意力头的维度
        self.all_head_size = int(self.num_heads * self.attention_head_size)
        # query, key, value 的线性变换（上述公式2）
        self.query = nn.Linear(self.embedding_dim, self.embedding_dim)  # 128, 128
        self.key = nn.Linear(self.embedding_dim, self.embedding_dim)
        self.value = nn.Linear(self.embedding_dim, self.embedding_dim)


        self.emb_dropout = nn.Dropout(0.25)
        self.dropout = nn.Dropout(0.1)

        self.gru = nn.GRU(self.embedding_dim, self.hidden_size, self.n_layers)
        self.a_1 = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        self.a_2 = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        self.v_t = nn.Linear(self.hidden_size, 1, bias=False)
        self.ct_dropout = nn.Dropout(0.5)
        self.b = nn.Linear(self.embedding_dim, 2 * self.hidden_size, bias=False)
        self.sf = nn.Softmax()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    def transpose_for_scores(self, x, attention_head_size):
        # INPUT:  x'shape = [bs, seqlen, hid_size]  假设hid_size=128
        new_x_shape = x.size()[:-1] + (self.num_heads, attention_head_size)  # [bs, seqlen, 8, 16]
        x = x.view(*new_x_shape)  #
        return x.permute(0, 2, 1, 3)

    def user_loss(self, user_emb, health_emb, harm_emb):
        # health_sim = self.cos_sim(self.ul_W1(user_emb), self.ul_W2(health_emb))
        # harm_sim = self.cos_sim(self.ul_W1(user_emb), self.ul_W3(harm_emb))

        health_sim = self.ul_W1(user_emb) * self.ul_W2(health_emb)
        health_sim = torch.sum(health_sim, -1)
        harm_sim = self.ul_W1(user_emb) * self.ul_W3(harm_emb)
        harm_sim = torch.sum(harm_sim, -1)

        # health_sim = user_emb * health_emb
        # health_sim = torch.sum(health_sim, -1)
        # harm_sim = user_emb + harm_emb
        # harm_sim = torch.sum(harm_sim, -1)

        ssl_loss = torch.log10(torch.exp(health_sim)) - torch.log10(torch.exp(health_sim) + torch.exp(harm_sim))
        ssl_loss = torch.sum(ssl_loss, 0)
        return -ssl_loss

    def forward(self, seq, lengths):
        hidden = self.init_hidden(seq.size(1))
        embs = self.emb_dropout(self.emb(seq))
        embs = pack_padded_sequence(embs, lengths)
        gru_out, hidden = self.gru(embs, hidden)
        gru_out, lengths = pad_packed_sequence(gru_out)


        # fetch the last hidden state of last timestamp
        ht = hidden[-1]
        gru_out = gru_out.permute(1, 0, 2)

        c_global = ht

        mask = torch.where(seq.permute(1, 0) > 0, torch.tensor([1.], device=self.device),
                           torch.tensor([0.], device=self.device))

        item_embs = self.emb(torch.arange(1, self.n_items).to(self.device))
        scores_rec = torch.matmul(c_global, item_embs.permute(1, 0))
        # scores_rec = torch.matmul(c_t, item_embs.permute(1, 0))

        # Self-attention healthy
        mask_h = mask.float().unsqueeze(-1)
        attention_mask = mask_h.permute(0, 2, 1).unsqueeze(1)  # [bs, 1, 1, seqlen] 增加维度
        attention_mask = (1.0 - attention_mask) * -10000.0

        seq_h = seq.permute(1, 0)
        item_f = self.emb_reason(seq_h)
        K_emb = item_f
        V_emb = item_f
        all_health = torch.cuda.LongTensor(list(K_emb.shape)[0], list(K_emb.shape)[1]).fill_(1)
        Q_emb = self.emb_healthy(all_health)
        Q_emb = self.dense_text_health(Q_emb)

        mixed_query_layer = self.query(Q_emb)  # [bs, seqlen, hid_size]
        mixed_key_layer = self.key(K_emb)  # [bs, seqlen, hid_size]
        mixed_value_layer = self.value(V_emb)  # [bs, seqlen, hid_size]

        attention_head_size = int(self.embedding_dim / self.num_heads)
        query_layer = self.transpose_for_scores(mixed_query_layer, attention_head_size)  # [bs, 8, seqlen, 16]
        key_layer = self.transpose_for_scores(mixed_key_layer, attention_head_size)
        value_layer = self.transpose_for_scores(mixed_value_layer, attention_head_size)  # [bs, 8, seqlen, 16]
        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        # [bs, 8, seqlen, 16]*[bs, 8, 16, seqlen]  ==> [bs, 8, seqlen, seqlen]
        attention_scores = attention_scores / math.sqrt(attention_head_size)  # [bs, 8, seqlen, seqlen]
        attention_scores = attention_scores + attention_mask
        attention_probs = nn.Softmax(dim=-1)(attention_scores)  # [bs, 8, seqlen, seqlen]
        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        attention_probs = self.dropout(attention_probs)

        # 矩阵相乘，[bs, 8, seqlen, seqlen]*[bs, 8, seqlen, 16] = [bs, 8, seqlen, 16]
        context_layer = torch.matmul(attention_probs, value_layer)  # [bs, 8, seqlen, 16]
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()  # [bs, seqlen, 8, 16]
        new_context_layer_shape = context_layer.size()[:-2] + (self.embedding_dim,)  # [bs, seqlen, 128]
        sa_result = context_layer.view(*new_context_layer_shape)
        # last hidden state
        mask_h = mask.long().unsqueeze(-1)
        item_pos = torch.tensor(range(1, V_emb.size()[1] + 1), device='cuda')
        item_pos = item_pos.unsqueeze(0).expand_as(seq_h)
        item_pos = item_pos * mask_h.squeeze(2)
        item_last_num = torch.max(item_pos, 1)[0].unsqueeze(1).expand_as(item_pos)
        last_pos_t = torch.where(item_pos - item_last_num >= 0, torch.tensor([1.0], device='cuda'),
                                 torch.tensor([0.0], device='cuda'))
        as_last_unit = last_pos_t.unsqueeze(2).expand_as(sa_result) * sa_result
        user_h = torch.sum(as_last_unit, 1)

        # item_embs_health = self.emb_reason(torch.arange(self.n_items).to(self.device))
        # scores_health = torch.matmul(user_h, item_embs_health.permute(1, 0))
        # scores = scores_rec + self.h_lambda*scores_health

        item_embs_reason = self.emb_reason(torch.arange(1, self.n_items).to(self.device))

        item_merge = item_embs_reason

        user_health = torch.cuda.LongTensor(list(user_h.shape)[0]).fill_(1)
        user_health_emb = self.emb_healthy(user_health)
        user_health_emb = self.dense_text_health(user_health_emb)

        scores_ui = torch.matmul(user_h, item_merge.permute(1, 0))
        scores_item = torch.matmul(user_health_emb, item_merge.permute(1, 0))
        scores = scores_rec
        # scores = scores_rec
        # scores = self.sf(scores)

        # ssl loss

        u_index = torch.cuda.LongTensor(list(user_h.shape)[0]).fill_(1)

        u_health_emb = self.emb_healthy(u_index)
        u_health_emb = self.dense_text_health(u_health_emb)

        u_harm_emb = self.emb_harmful(u_index)
        u_harm_emb = self.dense_text_harm(u_harm_emb)

        ssl_loss = self.user_lambda*self.user_loss(user_h, u_health_emb, u_harm_emb)


        return scores, ssl_loss, self.item_lambda * scores_item + self.ui_lambda * scores_ui

    def init_hidden(self, batch_size):
        return torch.zeros((self.n_layers, batch_size, self.hidden_size), requires_grad=True).to(self.device)