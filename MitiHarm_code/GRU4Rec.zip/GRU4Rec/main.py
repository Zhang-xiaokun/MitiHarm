#!/usr/bin/env python37
# -*- coding: utf-8 -*-

import os
import time
import random
import argparse
import pickle
import numpy as np
from tqdm import tqdm
from os.path import join

import torch
from torch import nn
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from torch.autograd import Variable
from torch.backends import cudnn

import metric
from utils import collate_fn
from gru4rec import GRU4Rec
from dataset import load_data, RecSysDataset

parser = argparse.ArgumentParser()
parser.add_argument('--dataset_path', default='datasetsHealth/TN/',
                    help='dataset directory path: TN/QB/NERD')
parser.add_argument('--batch_size', type=int, default=512, help='input batch size 512 ')
parser.add_argument('--embed_dim', type=int, default=100, help='the dimension of item embedding 50')
parser.add_argument('--hidden_size', type=int, default=100, help='hidden state size of gru module 100 ')
parser.add_argument('--epoch', type=int, default=100, help='the number of epochs to train for')
parser.add_argument('--lr', type=float, default=0.001, help='learning rate')
parser.add_argument('--lr_dc', type=float, default=0.1, help='learning rate decay rate')
parser.add_argument('--lr_dc_step', type=int, default=80,
                    help='the number of steps after which the learning rate decay')
# parser.add_argument('--test', action='store_true', help='test')
parser.add_argument('--test', default=True, help='False/True test')
parser.add_argument('--topk', type=int, default=20,
                    help='number of top score items selected for calculating recall and mrr metrics')
parser.add_argument('--valid_portion', type=float, default=0.1,
                    help='split the portion of training set as validation set')
args = parser.parse_args()
print(args)
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# here = os.path.dirname(os.path.abspath(__file__))
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

torch.cuda.set_device(3)


def main():
    print('Loading data...')
    # s1 s2 s3 s5 nd
    train, valid, test = load_data(args.dataset_path, valid_portion=args.valid_portion, maxlen=200, test_lab='test.txt')

    train_data = RecSysDataset(train)
    valid_data = RecSysDataset(valid)
    test_data = RecSysDataset(test)
    train_loader = DataLoader(train_data, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn)
    valid_loader = DataLoader(valid_data, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(test_data, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)

    if args.dataset_path.split('/')[-2] == 'TN':
        n_items = 3254 + 1 
    elif args.dataset_path.split('/')[-2] == 'QB':
        n_items = 5938 + 1
    elif args.dataset_path.split('/')[-2] == 'NERD':
        n_items = 10328 + 1
    else:
        raise Exception('Unknown Dataset!')

    model = GRU4Rec(n_items, args.hidden_size, args.embed_dim, args.batch_size, args.dataset_path.split('/')[-2]).to(device)

    if args.test:
        ckpt = torch.load('latest_checkpoint.pth.tar')
        model.load_state_dict(ckpt['state_dict'])
        begin_time = time.time()
        t1, t5, t10, t20 = validate_save(test_loader, model)
        end_time = time.time()
        run_time = end_time - begin_time
        print('Infer time：{:.4f}s\n'.format(run_time))

        # CKLLM 存储训练好的item embs,padding 0
        # save_path = args.dataset_path + '/item_embs.pth'
        # torch.save(model.emb.state_dict(), save_path)
        # print("Test: Recall@{}: {:.2f}, MRR@{}: {:.2f}, NDCG@{}: {:.2f}".format(args.topk, recall*100, args.topk, mrr*100, args.topk, ndcg*100))
        print("Test: P@1\t P@5\t M@5\t N@5\tP@10\t M@10\t N@10\tP@20\t M@20\t N@20")
        print("Test: {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}".format(t1[0] * 100, t5[0] * 100,t5[1] * 100,t5[2] * 100, t10[0] * 100,t10[1] * 100,t10[2] * 100,t20[0] * 100,t20[1] * 100,t20[2] * 100,))
        return

    optimizer = optim.Adam(model.parameters(), args.lr)
    criterion = nn.CrossEntropyLoss()
    scheduler = StepLR(optimizer, step_size=args.lr_dc_step, gamma=args.lr_dc)

    for epoch in tqdm(range(args.epoch)):
        # train for one epoch
        scheduler.step(epoch=epoch)

        begin_time = time.time()
        trainForEpoch(train_loader, model, optimizer, epoch, args.epoch, criterion, log_aggr=200)
        end_time = time.time()
        run_time = end_time - begin_time
        print('Epoch {} 运行时间：{:.4f}s\n'.format(epoch, run_time))
        # with open('result64.txt', 'a', encoding='utf-8') as f2:
        #     f2.write(str(run_time) + "\n")
        # f2.close()
        t1, t5, t10, t20 = validate(valid_loader, model)
        # print("Test: Recall@{}: {:.2f}, MRR@{}: {:.2f}, NDCG@{}: {:.2f}".format(args.topk, recall*100, args.topk, mrr*100, args.topk, ndcg*100))
        print("Valid: P@1\t P@5\t M@5\t N@5\tP@10\t M@10\t N@10\tP@20\t M@20\t N@20")
        print("Valid: {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}\t {:.2f}".format(
            t1[0] * 100, t5[0] * 100, t5[1] * 100, t5[2] * 100, t10[0] * 100, t10[1] * 100, t10[2] * 100, t20[0] * 100,
            t20[1] * 100, t20[2] * 100, ))

        # store best loss and save a model checkpoint
        ckpt_dict = {
            'epoch': epoch + 1,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict()
        }

        torch.save(ckpt_dict, 'latest_checkpoint.pth.tar')


def trainForEpoch(train_loader, model, optimizer, epoch, num_epochs, criterion, log_aggr=1):
    model.train()

    sum_epoch_loss = 0

    start = time.time()
    for i, (seq, target, lens) in tqdm(enumerate(train_loader), total=len(train_loader)):
        seq = seq.to(device)
        target = target.to(device)

        optimizer.zero_grad()
        outputs = model(seq, lens)
        loss = criterion(outputs, target)
        loss.backward()
        optimizer.step()

        loss_val = loss.item()
        sum_epoch_loss += loss_val

        iter_num = epoch * len(train_loader) + i + 1

        if i % log_aggr == 0:
            print('[TRAIN] epoch %d/%d batch loss: %.4f (avg %.4f) (%.2f im/s)'
                  % (epoch + 1, num_epochs, loss_val, sum_epoch_loss / (i + 1),
                     len(seq) / (time.time() - start)))

        start = time.time()


def validate(valid_loader, model):
    model.eval()
    recalls1 = []
    recalls5 = []
    mrrs5 = []
    ndcgs5 = []
    recalls10 = []
    mrrs10 = []
    ndcgs10 = []
    recalls20 = []
    mrrs20 = []
    ndcgs20 = []
    with torch.no_grad():
        for seq, target, lens in tqdm(valid_loader):
            seq = seq.to(device)
            target = target.to(device)
            outputs = model(seq, lens)
            logits = F.softmax(outputs, dim=1)
            top1 = []
            top5 = []
            top10 = []
            top20 = []
            recall1, mrr1, ndcg1 = metric.evaluate(logits, target, 1)
            recall5, mrr5, ndcg5 = metric.evaluate(logits, target, 5)
            recall10, mrr10, ndcg10 = metric.evaluate(logits, target, 10)
            recall20, mrr20, ndcg20 = metric.evaluate(logits, target, 20)
            recalls1.append(recall1)
            recalls5.append(recall5)
            mrrs5.append(mrr5)
            ndcgs5.append(ndcg5)
            recalls10.append(recall10)
            mrrs10.append(mrr10)
            ndcgs10.append(ndcg10)
            recalls20.append(recall20)
            mrrs20.append(mrr20)
            ndcgs20.append(ndcg20)
            # recall, mrr, ndcg = metric.evaluate(logits, target, k=args.topk)
            # recalls.append(recall)
            # mrrs.append(mrr)
            # ndcgs.append(ndcg)

    mean_recall1 = np.mean(recalls1)

    mean_recall5 = np.mean(recalls5)
    mean_mrr5 = np.mean(mrrs5)
    mean_ndcg5 = np.mean(ndcgs5)
    mean_recall10 = np.mean(recalls10)
    mean_mrr10 = np.mean(mrrs10)
    mean_ndcg10 = np.mean(ndcgs10)
    mean_recall20 = np.mean(recalls20)
    mean_mrr20 = np.mean(mrrs20)
    mean_ndcg20 = np.mean(ndcgs20)
    result_top1 = [mean_recall1]
    result_top5 = [mean_recall5, mean_mrr5, mean_ndcg5]
    result_top10 = [mean_recall10, mean_mrr10, mean_ndcg10]
    result_top20 = [mean_recall20, mean_mrr20, mean_ndcg20]
    return result_top1, result_top5, result_top10, result_top20

def validate_save(valid_loader, model):
    model.eval()
    recalls1 = []
    recalls5 = []
    mrrs5 = []
    ndcgs5 = []
    recalls10 = []
    mrrs10 = []
    ndcgs10 = []
    recalls20 = []
    mrrs20 = []
    ndcgs20 = []
    seq_save = []
    label_save = []
    pre_save = []
    with torch.no_grad():
        for seq, target, lens in tqdm(valid_loader):
            seq = seq.to(device)
            target = target.to(device)
            outputs = model(seq, lens)
            logits = F.softmax(outputs, dim=1)
            top1 = []
            top5 = []
            top10 = []
            top20 = []

            # top-k item ID number
            # pre_k = torch.topk(logits, 20, -1)[1]
            # seq_temp = seq.transpose(0,1).tolist()
            # seq_save += seq_temp
            # label_save += target.tolist()
            # pre_save += pre_k.tolist()



            recall1, mrr1, ndcg1 = metric.evaluate(logits, target, 1)
            recall5, mrr5, ndcg5 = metric.evaluate(logits, target, 5)
            recall10, mrr10, ndcg10 = metric.evaluate(logits, target, 10)
            recall20, mrr20, ndcg20 = metric.evaluate(logits, target, 20)
            recalls1.append(recall1)
            recalls5.append(recall5)
            mrrs5.append(mrr5)
            ndcgs5.append(ndcg5)
            recalls10.append(recall10)
            mrrs10.append(mrr10)
            ndcgs10.append(ndcg10)
            recalls20.append(recall20)
            mrrs20.append(mrr20)
            ndcgs20.append(ndcg20)
            # recall, mrr, ndcg = metric.evaluate(logits, target, k=args.topk)
            # recalls.append(recall)
            # mrrs.append(mrr)
            # ndcgs.append(ndcg)

    # save predictions
    # pre_save_path = args.dataset_path + "/prediction_health.txt"
    # res_pre = (seq_save, label_save, pre_save)
    # pickle.dump(res_pre, open(pre_save_path, 'wb'))

    mean_recall1 = np.mean(recalls1)

    mean_recall5 = np.mean(recalls5)
    mean_mrr5 = np.mean(mrrs5)
    mean_ndcg5 = np.mean(ndcgs5)
    mean_recall10 = np.mean(recalls10)
    mean_mrr10 = np.mean(mrrs10)
    mean_ndcg10 = np.mean(ndcgs10)
    mean_recall20 = np.mean(recalls20)
    mean_mrr20 = np.mean(mrrs20)
    mean_ndcg20 = np.mean(ndcgs20)
    result_top1 = [mean_recall1]
    result_top5 = [mean_recall5, mean_mrr5, mean_ndcg5]
    result_top10 = [mean_recall10, mean_mrr10, mean_ndcg10]
    result_top20 = [mean_recall20, mean_mrr20, mean_ndcg20]
    return result_top1, result_top5, result_top10, result_top20

if __name__ == '__main__':
    main()
